Kamal Khan & Brother's Hardware Store
Shop Billing & Stock System

This first build contains the project specification and a starter Windows application.
Core features:
- Products/items
- Stock quantity
- Selling price
- Cart/bill
- Automatic totals in PKR
- Save products and sales locally
- Printable receipt foundation

Android version will use the same data model and business logic in the next build.
