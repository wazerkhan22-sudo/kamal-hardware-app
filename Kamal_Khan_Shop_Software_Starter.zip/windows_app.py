import tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path
import json

DATA = Path(__file__).with_name("shop_data.json")

def load_data():
    if DATA.exists():
        try:
            return json.loads(DATA.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {"products": [], "sales": []}

data = load_data()

def save_data():
    DATA.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

def refresh_products():
    for x in tree.get_children():
        tree.delete(x)
    for p in data["products"]:
        tree.insert("", "end", values=(p["name"], p["price"], p["stock"]))

def add_product():
    name = name_var.get().strip()
    if not name:
        messagebox.showwarning("Item", "Enter item name.")
        return
    try:
        price = float(price_var.get())
        stock = int(stock_var.get())
    except ValueError:
        messagebox.showwarning("Input", "Price must be a number and stock must be a whole number.")
        return
    data["products"].append({"name": name, "price": price, "stock": stock})
    save_data()
    name_var.set(""); price_var.set(""); stock_var.set("")
    refresh_products()

root = tk.Tk()
root.title("Kamal Khan & Brother's Hardware Store")
root.geometry("850x560")
root.minsize(760, 500)

title = ttk.Label(root, text="Kamal Khan & Brother's Hardware Store", font=("Segoe UI", 18, "bold"))
title.pack(pady=12)

form = ttk.LabelFrame(root, text="Add Item")
form.pack(fill="x", padx=15, pady=5)

name_var = tk.StringVar()
price_var = tk.StringVar()
stock_var = tk.StringVar()

ttk.Label(form, text="Item Name").grid(row=0, column=0, padx=8, pady=10)
ttk.Entry(form, textvariable=name_var, width=30).grid(row=0, column=1, padx=8)
ttk.Label(form, text="Price (PKR)").grid(row=0, column=2, padx=8)
ttk.Entry(form, textvariable=price_var, width=15).grid(row=0, column=3, padx=8)
ttk.Label(form, text="Stock").grid(row=0, column=4, padx=8)
ttk.Entry(form, textvariable=stock_var, width=12).grid(row=0, column=5, padx=8)
ttk.Button(form, text="Add Item", command=add_product).grid(row=0, column=6, padx=12)

box = ttk.LabelFrame(root, text="Items / Stock")
box.pack(fill="both", expand=True, padx=15, pady=10)

tree = ttk.Treeview(box, columns=("name","price","stock"), show="headings")
tree.heading("name", text="Item Name")
tree.heading("price", text="Price (PKR)")
tree.heading("stock", text="Stock")
tree.column("name", width=420)
tree.column("price", width=160, anchor="center")
tree.column("stock", width=120, anchor="center")
tree.pack(fill="both", expand=True, padx=8, pady=8)

status = ttk.Label(root, text="Ready", anchor="w")
status.pack(fill="x", padx=15, pady=(0,10))

refresh_products()
root.mainloop()
