from flask import Flask, request
from datetime import datetime
import json

app = Flask(__name__)

def load_items():
    with open("items.json", "r") as file:
        return json.load(file)

def save_items(items):
    with open("items.json", "w") as file:
        json.dump(items, file, indent=4)


def load_bills():
    try:
        with open("bills.json", "r") as file:
            return json.load(file)
    except (FileNotFoundError, json.JSONDecodeError):
        return []

def save_bills(bills):
    with open("bills.json", "w") as file:
        json.dump(bills, file, indent=4)


@app.route("/")
def home():
    return """
    <html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Kamal Khan Hardware Store</title>
    </head>
    <body>
        <h1>Kamal Khan & Brother's Hardware Store</h1>
        <h2>Billing Software</h2>
        <hr>
        <button onclick="location.href='/add_item'">Add New Item</button><br><br>
        <button onclick="location.href='/items'">View Items</button><br><br>
        <button onclick="location.href='/new_bill'">New Bill</button><br><br>
        <button onclick="location.href='/add_stock'">Add Stock</button><br><br>
        <button onclick="location.href='/edit_item'">Edit Item</button><br><br><button onclick="location.href='/delete_item'">Delete Item</button><br><br>
        <button onclick="location.href='/last_bill'">Last Bill</button><br><br>
        <button onclick="location.href='/bill_history'">Bill History</button>
    </body>
    </html>
    """

@app.route("/items")
def view_items():
    items = load_items()
    html = """
    <html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Items</title>
    </head>
    <body>
        <h1>Items / Stock</h1>
        <hr>
    """
    if not items:
        html += "<p>No items found.</p>"
    else:
        for name, data in items.items():
            html += f"""
            <p>
            <b>{name}</b><br>
            Unit: {data['unit']}<br>
            Price: {data['price']} PKR<br>
            Stock: {data.get('stock', 0)}
            </p>
            <hr/>
            """
        html += '<br><button onclick="location.href='"'"'/'"'"'">Back to Main Menu</button>'
        html += "</html>"
    return html

@app.route("/add_item", methods=["GET", "POST"])
def add_item():
    message = ""
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        unit = request.form.get("unit", "").strip()
        price_text = request.form.get("price", "").strip()
        stock_text = request.form.get("stock", "").strip()

        if not name or not unit or not price_text or not stock_text:
            message = "Please fill all fields."
        else:
            items = load_items()
            if any(x.lower() == name.lower() for x in items):
                message = "Item already exists!"
            else:
                try:
                    price = float(price_text)
                    stock = float(stock_text)
                    if price <= 0 or stock < 0:
                        message = "Price must be greater than 0 and stock cannot be negative."
                    else:
                        items[name] = {"unit": unit, "price": price, "stock": stock}
                        save_items(items)
                        return "<h2>Item saved successfully!</h2><br><button onclick='location.href="/"'>Back to Main Menu</button>"
                except ValueError:
                    message = "Price and stock must be numbers."

    return f"""
    <html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Add New Item</title>
    </head>
    <body>
        <h1>Add New Item</h1>
        <p>{message}</p>
        <form method="post">
            Item Name:<br>
            <input name="name"><br><br>
            Unit (KG/PCS/Dozen/Meter/Foot):<br>
            <input name="unit"><br><br>
            Price per Unit (PKR):<br>
            <input name="price" type="number" step="any"><br><br>
            Opening Stock<br>
            <input name="stock" type="number" step="any"><br><br>
            <button type="submit">Save Item</button>
        </form>
        <br>
        <button onclick="location.href='/'">Back to Main Menu</button>
    </body>
    </html>
    """

@app.route("/new_bill")
def new_bill():
    items = load_items()

    options = '<option value="">-- Select Item --</option>'
    for name, data in items.items():
        options += f'<option value="{name}">{name} - {data.get("unit", "")} - {data["price"]} PKR</option>'

    html = f"""
    <html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>New Bill</title>
    </head>
    <body>
        <h1>New Bill</h1>
        <hr>

        <form method="post" action="/create_bill">

            <b>Customer Name:</b><br>
            <input name="customer_name" type="text" placeholder="Customer Name" required><br><br>

            <b>Customer Phone:</b><br>
            <input name="customer_phone" type="tel" placeholder="Phone Number" required><br><br>

            <hr>

            <div id="items">
                <div class="item-row">
                    <b>Item 1:</b><br>
                    <select name="item">
                        {options}
                    </select><br>
                    Quantity:<br>
                    <input name="quantity" type="number" step="any" min="0.01">
                    <button type="button" onclick="this.parentElement.remove()">Remove</button>
                    <br><br>
                </div>
            </div>

            <button type="button" onclick="addItem()">➕ Add Item</button>
            <br><br>
            <button type="submit">Create Bill</button>
        </form>

        <br>
        <button onclick="location.href='/'">Back to Main Menu</button>

        <script>
        let itemCount = 1;

        function addItem() {{
            itemCount++;

            let div = document.createElement("div");
            div.className = "item-row";

            div.innerHTML = `
                <b>Item ${{itemCount}}:</b><br>
                <select name="item">
                    {options}
                </select><br>
                Quantity:<br>
                <input name="quantity" type="number" step="any" min="0.01">
                <button type="button" onclick="this.parentElement.remove()">Remove</button>
                <br><br>
            `;

            document.getElementById("items").appendChild(div);
        }}
        </script>

    </body>
    </html>
    """

    return html

@app.route("/create_bill", methods=["POST"])
def create_bill():
    customer_name = request.form.get("customer_name", "").strip()
    customer_phone = request.form.get("customer_phone", "").strip()

    item_names = request.form.getlist("item")
    quantities = request.form.getlist("quantity")

    items = load_items()

    bill_items = []
    grand_total = 0
    requested_stock = {}

    for item_name, quantity_text in zip(item_names, quantities):
        if not item_name:
            continue

        try:
            quantity = float(quantity_text)
        except ValueError:
            return "<h2>Invalid quantity!</h2><br><button onclick=\"location.href='/new_bill'\">Back</button>"

        if quantity <= 0:
            continue

        if item_name not in items:
            return f"<h2>Item not found: {item_name}</h2><br><button onclick=\"location.href='/new_bill'\">Back</button>"

        price = float(items[item_name]["price"])
        stock = float(items[item_name].get("stock", 0))

        requested_stock[item_name] = requested_stock.get(item_name, 0) + quantity

        if requested_stock[item_name] > stock:
            return f"<h2>Not enough stock for {item_name}!</h2><p>Available stock: {stock}</p><br><button onclick=\"location.href='/new_bill'\">Back</button>"

        total = price * quantity

        bill_items.append({
            "item": item_name,
            "quantity": quantity,
            "unit": items[item_name].get("unit", ""), 
            "price": price,
            "total": total
        })

        grand_total += total

    if not bill_items:
        return "<h2>Please add at least one item!</h2><br><button onclick=\"location.href='/new_bill'\">Back</button>"

    for bill_item in bill_items:
        name = bill_item["item"]
        items[name]["stock"] = float(items[name].get("stock", 0)) - bill_item["quantity"]

    save_items(items)

    bills = load_bills()
    bill_no = datetime.now().strftime("%Y%m%d-%H%M%S")
    bill_date = datetime.now().strftime("%d-%m-%Y")
    bill_time = datetime.now().strftime("%I:%M %p")

    bills.append({
        "bill_no": bill_no,
        "date": bill_date,
        "time": bill_time,
        "customer_name": customer_name,
        "customer_phone": customer_phone,
        "items": bill_items,
        "total": grand_total
    })

    save_bills(bills)

    html = f"""
    <html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Bill</title>
        <style>
            body {{
                font-family: Arial, sans-serif;
                max-width: 600px;
                margin: auto;
                padding: 15px;
            }}

            .shop-name {{
                text-align: center;
                font-size: 24px;
                font-weight: bold;
            }}

            .bill-title {{
                text-align: center;
                font-size: 20px;
            }}

            .info {{
                line-height: 1.8;
            }}

            .item {{
                border-bottom: 1px solid #ccc;
                padding: 10px 0;
            }}

            .bill-table {{
                width: 100%;
                border-collapse: collapse;
                margin-top: 15px;
            }}

            .bill-table th,
            .bill-table td {{
                border: 1px solid #999;
                padding: 10px 6px;
                text-align: center;
            }}

            .bill-table th {{
                font-weight: bold;
            }}

            .bill-table td:first-child {{
                text-align: left;
            }}

            .grand-total {{
                text-align: right;
                font-size: 22px;
                font-weight: bold;
                margin-top: 15px;
            }}

            button {{
                width: 100%;
                padding: 12px;
                margin-top: 8px;
                font-size: 16px;
            }}

            @media print {{
                button {{
                    display: none;
                }}
            }}
        </style>
    </head>
    <body>
        <h1>Kamal Khan & Brother's Hardware Store</h1>
        <h2>Bill</h2>
        <hr>

        Bill Number: {bill_no}<br>
        Date: {bill_date}<br>
        Time: {bill_time}<br>
        Customer Name: {customer_name}<br>
        Customer Phone: {customer_phone}<br>

        <hr>
    """

    html += f"""
        <table class="bill-table">
            <tr>
                <th>Item</th>
                <th>Qty</th>
                <th>Unit</th>
                <th>Price</th>
                <th>Total</th>
            </tr>
    """

    for bill_item in bill_items:
        html += f"""
            <tr>
                <td>{bill_item["item"]}</td>
                <td>{bill_item["quantity"]}</td>
                <td>{bill_item["unit"]}</td>
                <td>{bill_item["price"]:.2f}</td>
                <td>{bill_item["total"]:.2f}</td>
            </tr>
        """

    html += f"""
        </table>
    """

    html += f"""
        <h2>Grand Total: {grand_total:.2f} PKR</h2>

        <button onclick="location.href='/print_bill'">Print Bill</button>
        <br><br>
        <button onclick="location.href='/new_bill'">New Bill</button>
        <br><br>
        <button onclick="location.href='/'">Main Menu</button>

    </body>
    </html>
    """

    return html

@app.route("/add_stock", methods=["GET", "POST"])
def add_stock():
    items = load_items()
    message = ""

    if request.method == "POST":
        item_name = request.form.get("item", "")
        quantity_text = request.form.get("quantity", "")

        try:
            quantity = float(quantity_text)

            if quantity <= 0:
                message = "Quantity must be greater than 0."
            elif item_name not in items:
                message = "Item not found."
            else:
                old_stock = float(items[item_name].get("stock", 0))
                items[item_name]["stock"] = old_stock + quantity
                save_items(items)
                message = f"Stock added successfully! New stock: {old_stock + quantity}"

        except ValueError:
            message = "Please enter a valid quantity."

    html = f"""
    <html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Add Stock</title>
    </head>
    <body>
        <h1>Add Stock</h1>
        <p>{message}</p>

        <form method="post">
            Item:<br>
            <select name="item">
    """

    for name, data in items.items():
        html += f'<option value="{name}" data-unit="{items[name].get("unit","")}" data-price="{items[name].get("price",0)}" data-stock="{items[name].get("stock",0)}">{name}</option>'

    html += f"""
            </select><br><br>

            Add Quantity:<br>
            <input name="quantity" type="number" step="any" min="0.01"><br><br>

            <button type="submit">Add Stock</button>
        </form>

        <br>
        <button onclick="location.href='/'">Back to Main Menu</button>
    </body>
    </html>
    """

    return html
@app.route("/edit_item", methods=["GET", "POST"])
def edit_item():
    items = load_items()
    message = ""

    if request.method == "POST":
        old_name = request.form.get("old_name", "")
        new_name = request.form.get("new_name", "").strip()
        unit = request.form.get("unit", "").strip()
        price_text = request.form.get("price", "")
        stock_text = request.form.get("stock", "")

        try:
            price = float(price_text)
            stock = float(stock_text)

            if not new_name:
                message = "Item name cannot be empty."
            elif old_name not in items:
                message = "Item not found."
            elif new_name != old_name and new_name in items:
                message = "This item name already exists."
            else:
                data = items.pop(old_name)
                data["unit"] = unit
                data["price"] = price
                data["stock"] = stock
                items[new_name] = data
                save_items(items)
                message = "Item updated successfully!"

        except ValueError:
            message = "Please enter valid price and stock."

    html = f"""
    <html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Edit Item</title>
    </head>
    <body>
        <h1>Edit Item</h1>
        <p>{message}</p>

        <form method="post">
            Select Item:<br>
            <select name="old_name" onchange="let o=this.options[this.selectedIndex];document.querySelector('[name=new_name]').value=o.text;document.querySelector('[name=unit]').value=o.dataset.unit;document.querySelector('[name=price]').value=o.dataset.price;document.querySelector('[name=stock]').value=o.dataset.stock;">
    """

    for name in items:
        html += f'<option value="{name}" data-unit="{items[name].get("unit","")}" data-price="{items[name].get("price",0)}" data-stock="{items[name].get("stock",0)}">{name}</option>'

    html += f"""
            </select><br><br>

            New Item Name:<br>
            <input name="new_name" type="text"><br><br>

            Unit:<br>
            <input name="unit" type="text"><br><br>

            Price (PKR):<br>
            <input name="price" type="number" step="any"><br><br>

            Stock:<br>
            <input name="stock" type="number" step="any"><br><br>

            <button type="submit">Save Changes</button>
        </form>

        <br>
        <button onclick="location.href='/'">Back to Main Menu</button>
    </body>
    </html>
    """

    return html

@app.route("/last_bill")
def last_bill():
    bills = load_bills()

    if not bills:
        return """
        <h2>No bills found</h2>
        <br>
        <button onclick="location.href='/'">Main Menu</button>
        """

    bill = bills[-1]

    html = f"""
    <html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Last Bill</title>
    </head>
    <body>
        <h1>Kamal Khan & Brother's Hardware Store</h1>
        <h2>Last Bill</h2>
        <hr>

        <p><b>Bill Number:</b> {bill.get("bill_no", "Old Bill")}</p>
        <p><b>Date:</b> {bill.get("date", "-")}</p>
        <p><b>Time:</b> {bill.get("time", "-")}</p>
        <p><b>Customer Name:</b> {bill.get("customer_name", "-")}</p>
        <p><b>Customer Phone:</b> {bill.get("customer_phone", "-")}</p>

        <hr>
    """

    if "items" in bill:
        for bill_item in bill["items"]:
            html += f"""
            <p><b>{bill_item["item"]}</b> — {bill_item["quantity"]} {bill_item.get("unit", "-")} × {bill_item["price"]} = <b>{bill_item["total"]} PKR</b></p>
            <hr>
            """

        html += f"""
        <h2>Grand Total: {bill["total"]} PKR</h2>
        """

    else:
        html += f"""
        <p><b>Item:</b> {bill["item"]}</p>
        <p><b>Quantity:</b> {bill["quantity"]}</p>
        <p><b>Price:</b> {bill["price"]} PKR</p>
        <h2>Total: {bill["total"]} PKR</h2>
        """

    html += f"""
        <button onclick="location.href='/print_bill'">Print Bill</button>
        <br><br>
        <button onclick="location.href='/new_bill'">New Bill</button>
        <br><br>
        <button onclick="location.href='/'">Main Menu</button>
    </body>
    </html>
    """

    return html

@app.route("/print_bill")
def print_bill():
    bills = load_bills()
    if not bills:
        return "<h2>No bills found</h2>"
    bill = bills[-1]
    html = f"""
    <html>
    <head><meta name="viewport" content="width=80mm"><title>Print Bill</title><style>body{{width:80mm;margin:0 auto;font-family:Arial,sans-serif;font-size:12px;}}h1{{font-size:18px;text-align:center;}}h2{{font-size:16px;}}p{{margin:4px 0;}}</style></head>
<style>body{{width:80mm;margin:0 auto;font-family:Arial,sans-serif;font-size:12px;}}h1{{font-size:16px;text-align:center;margin:0 0 6px;}}h2{{font-size:15px;text-align:right;margin:8px 0;}}p{{margin:3px 0;}}hr{{border:0;border-top:1px dashed #000;margin:6px 0;}}</style>

    <body><button onclick="window.print(); return false;">Print</button>
    <h1>Kamal Khan & Brother's Hardware Store</h1>
    <hr>
    <p><b>Bill Number:</b> {bill.get("bill_no", "Old Bill")}</p>
    <p><b>Date:</b> {bill.get("date", "-")}</p>
    <p><b>Time:</b> {bill.get("time", "-")}</p>
    <p><b>Customer Name:</b> {bill.get("customer_name", "-")}</p>
    <p><b>Customer Phone:</b> {bill.get("customer_phone", "-")}</p>
    <hr>
    """
    if "items" in bill:
        for bill_item in bill["items"]:
            html += f"""
            <p><b>{bill_item["item"]}</b> — {bill_item["quantity"]} {bill_item.get("unit", "-")} × {bill_item["price"]} = <b>{bill_item["total"]} PKR</b></p>
            <hr>
            """
        html += f"<h2>Grand Total: {bill["total"]} PKR</h2>"
    html += "<p style='text-align:center;font-weight:bold;margin-top:12px;'>Thank You!</p>"
    html += "</body></html>"
    return html

@app.route("/bill_history")
def bill_history():
    bills = load_bills()

    html = """
    <html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Bill History</title>
    </head>
    <body>
        <h1>Kamal Khan & Brother's Hardware Store</h1>
        <h2>Bill History</h2>
        <hr>
    """

    if not bills:
        html += "<h3>No bills found</h3>"
    else:
        for number, bill in enumerate(reversed(bills), 1):
            html += f"""
            <div>
                <h3>Bill #{number}</h3>
                Bill Number: {bill.get("bill_no", "Old Bill")}<br>
                Date: {bill.get("date", "-")}<br>
                Time: {bill.get("time", "-")}<br>
                Customer Name: {bill.get("customer_name", "-")}<br>
                Customer Phone: {bill.get("customer_phone", "-")}<br>
                <hr>
            """

            if "items" in bill:
                for bill_item in bill["items"]:
                    html += f"""
                    <b>Item:</b> {bill_item["item"]}<br>
                    Quantity: {bill_item["quantity"]}<br>
                    Unit: {bill_item.get("unit", "-")}<br>
                    Price: {bill_item["price"]} PKR<br>
                    Total: {bill_item["total"]} PKR
                    <hr>
                    """

                html += f"""
                    <b>Grand Total: {bill["total"]} PKR</b>
                """

            else:
                html += f"""
                    Item: {bill["item"]}<br>
                    Quantity: {bill["quantity"]}<br>
                    Price: {bill["price"]} PKR<br>
                    <b>Total: {bill["total"]} PKR</b>
                """

            html += f"""
                <hr>
                <button onclick="location.href='/print_bill?bill_no={bill.get("bill_no", "")}'">Print Bill</button>
            </div>
            """

    html += f"""
        <button onclick="location.href='/'">Main Menu</button>
    </body>
    </html>
    """

    return html


@app.route("/delete_item", methods=["GET", "POST"])
def delete_item():
    items = load_items()
    message = ""
    if request.method == "POST":
        item_name = request.form.get("item_name", "")
        if item_name in items:
            items.pop(item_name)
            save_items(items)
            message = "Item deleted successfully!"
        else:
            message = "Item not found."
    html = """
    <html><head><meta name="viewport" content="width=device-width, initial-scale=1"><title>Delete Item</title></head>
    <body><h1>Delete Item</h1><p>""" + message + """</p>
    <form method="post">
    Select Item:<br>
    <select name="item_name">
    """
    for name in items:
        html += f'<option value="{name}">{name}</option>'
    html += """
    </select><br><br>
    <button type="submit" onclick="return confirm('Are you sure you want to delete this item?')">Delete Item</button>
    </form><br>
    <button onclick="location.href='/'">Back to Main Menu</button>
    </body></html>"""
    return html

if __name__ == "__main__": app.run(host="0.0.0.0", port=5000, debug=False)
